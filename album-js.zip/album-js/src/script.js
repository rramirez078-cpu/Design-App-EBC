//Array(Arreglo) para las imagenes, aquí van a poner las imagenes//
// de cada uno ( ES INDIVIDUAL) //

//fotos de Unsplash (ajustadas con w=400&h=300&fit=crop)//

const imagenes = [
  "https://images.pexels.com/photos/46216/sunflower-flowers-bright-yellow-46216.jpeg",
  
  "https://images.pexels.com/photos/39517/rose-flower-blossom-bloom-39517.jpeg",
  
  "https://images.pexels.com/photos/992734/pexels-photo-992734.jpeg",
  
  "https://images.pexels.com/photos/132474/pexels-photo-132474.jpeg",
  
 "https://images.pexels.com/photos/1369068/pexels-photo-1369068.jpeg",
  
  "https://images.pexels.com/photos/60909/rose-yellow-flower-petals-60909.jpeg"
];

//Seleccion de elementos // 

const boton = document.getElementById("btn-cambiar");
const imagenCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

//contador de las imagenes//

let indice = 0;

//evento del click//
boton.addEventListener("click", () => {
 
 //lo siguiente es para que avance la foto //
  indice++;

//el siguiente if es para que cuando llegue al final se regrese al inicio//
  
  if (indice >= imagenes.length) {
    indice = 0;
  }
      // Cambiar imagen y texto //
imagenCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
});
     