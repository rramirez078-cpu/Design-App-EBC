# Album JS

A Pen created on CodePen.

Original URL: [https://codepen.io/RUTH-RAMIREZMUNOZ/pen/LEpvoYK](https://codepen.io/RUTH-RAMIREZMUNOZ/pen/LEpvoYK).

