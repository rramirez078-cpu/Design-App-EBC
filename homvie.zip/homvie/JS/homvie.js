function toggleComments(id) {
  const elem = document.getElementById(id);
  // Si no hay comentarios, agregamos un mensaje por defecto
  if (elem.innerHTML.trim() === "") {
    elem.innerHTML = "<p>No hay comentarios aún.</p>";
  }
  elem.style.display = elem.style.display === "block" ? "none" : "block";
}

function likeFunction(button) {
  // Verificamos si ya tiene palomita para no duplicar
  if (!button.innerHTML.includes("✓")) {
    button.style.fontWeight = "bold";
    button.innerHTML = "✓ Liked";
  }
}

function toggleModal(id) {
  const modal = document.getElementById(id);
  modal.style.display = modal.style.display === "flex" ? "none" : "flex";
}

function scrollToTop() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ====================
// Carrusel automático
// ====================
let currentSlide = 0;
const slides = document.querySelectorAll(".hero-carousel .slide");

function showSlide(index) {
  slides.forEach((slide, i) => {
    slide.classList.remove("active");
    if (i === index) slide.classList.add("active");
  });
}

function nextSlide() {
  currentSlide = (currentSlide + 1) % slides.length;
  showSlide(currentSlide);
}

// Cambia cada 10 segundos
setInterval(nextSlide, 5000);

// Muestra la primera slide al cargar
showSlide(currentSlide);
